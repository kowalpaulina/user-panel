import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-users-panel',
  templateUrl: './users-panel.component.html',
  styleUrls: ['./users-panel.component.scss']
})
export class UsersPanelComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
