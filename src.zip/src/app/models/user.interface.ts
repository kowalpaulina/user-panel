export interface User {
  id?: string;
  name: string;
  lastname: string;
  city: string;
  country: string;
  temperature?: any;
  humidity?: any;
}